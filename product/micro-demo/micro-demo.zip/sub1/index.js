
$('.button').on('click',function(){
  $('.red').css("background", '#000')
})
