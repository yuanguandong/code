
$('.button').on('click',function(){
  $('.red').css("background", 'green')
})
